// JavaScript to handle direct call when clicking contact button or number

document.addEventListener("DOMContentLoaded", function () {
  const contactButton = document.querySelector(".btn");
  const contactLinks = document.querySelectorAll("a[href^='tel:0762907273']");

  const phoneNumber = "0762907273";
  const telURL = `tel:${phoneNumber}`;

  if (contactButton) {
    contactButton.addEventListener("click", function (e) {
      e.preventDefault();
      window.location.href = telURL; // Directly initiates a call
    });
  }

  contactLinks.forEach(link => {
    link.addEventListener("click", function (e) {
      e.preventDefault();
      window.location.href = telURL; // Also initiates a call
    });
  });
});

